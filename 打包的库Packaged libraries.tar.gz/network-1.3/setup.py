from setuptools import setup
setup(
    name='network',
    version='1.3',
    description='',
    author='',
    author_email='',
    url='',
    py_modules=['network'],
)
